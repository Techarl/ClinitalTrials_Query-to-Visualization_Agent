"""Frozen-transfer Harness study with public-only selection and USD-matched retries."""

import argparse
import json
from collections import Counter
from contextlib import contextmanager
from pathlib import Path

from app.config import Settings
from app.sources import content_hash
from app.v2.skills import BUILTINS
from evaluation.contracts import Episode
from evaluation.protocol import execution_identity, freeze
from evaluation.runtime import PersistentBudget, run_episode, write
from experiments.harness_v2 import ExperienceBank, ppc, quality


def selection(cases):
    """Select by public split/entity/family only, before observing any result."""
    development = [e for e in cases if e.split == "development"]
    families = list(dict.fromkeys(e.family for e in development))
    groups = list(dict.fromkeys(e.entity_group for e in development))
    dev = [
        next(e for e in development if e.family == f and e.entity_group == groups[i % len(groups)])
        for i, f in enumerate(families)
    ][:20]
    held = [e for e in cases if e.split == "heldout"]
    held_groups = list(dict.fromkeys(e.entity_group for e in held))
    held_families = list(dict.fromkeys(e.family for e in held))
    formal = [
        next(
            e
            for e in held
            if e.entity_group == group and e.family == held_families[(i * 4 + j) % len(held_families)]
        )
        for i, group in enumerate(held_groups)
        for j in range(4)
    ]
    assert len(dev) == 20 and len({e.id for e in formal}) == 40
    return dev, formal


def event_cost(event):
    return event.get("estimated_cost_usd", event["reserved_upper_estimate_usd"])


def metrics(events):
    return {
        "calls": len(events),
        "usd": sum(event_cost(e) for e in events),
        "input_tokens": sum(
            (e.get("metadata", {}).get("usage") or {}).get("input_tokens", 0) for e in events
        ),
        "output_tokens": sum(
            (e.get("metadata", {}).get("usage") or {}).get("output_tokens", 0) for e in events
        ),
        "unknown_usage_calls": sum(e["status"] != "completed" for e in events),
    }


class StudyBudget(PersistentBudget):
    """One persistent ledger with tagged arms and independently bounded USD slices."""

    def __init__(self, path, max_usd):
        super().__init__(path, max_usd=max_usd, max_calls=20000)
        self.scope_name, self.scope_limit = "unassigned", None

    def scope_events(self, name=None):
        return [e for e in self.events if e.get("study_scope") == (name or self.scope_name)]

    @contextmanager
    def scope(self, name, limit=None):
        previous = self.scope_name, self.scope_limit
        self.scope_name, self.scope_limit = name, limit
        try:
            yield
        finally:
            self.scope_name, self.scope_limit = previous

    def before(self, context_bytes, output_tokens=4096):
        upper = (context_bytes * 2.5 + output_tokens * 10) / 1_000_000
        with self.lock:
            if (
                self.scope_limit is not None
                and metrics(self.scope_events())["usd"] + upper > self.scope_limit
            ):
                raise RuntimeError("USD-matched retry allocation exhausted before request")
            event = super().before(context_bytes, output_tokens)
            event["study_scope"] = self.scope_name
            write(self.path, self.report())
            return event


def copy_bank(entries):
    bank = ExperienceBank()
    bank.entries = json.loads(json.dumps(entries))
    return bank


def mechanism_counts(path, entries):
    learned, builtin = set(), set()
    for item in entries.values():
        data = {**item, "procedure": item.get("procedure", item.get("component", {}).get("skill", ""))}
        learned.add("skill_" + content_hash(data)[:24])
    for item in BUILTINS:
        builtin.add("skill_" + content_hash(item)[:24])
    counts = Counter()
    ids = {"read": [], "applied": []}
    for turn in sorted(Path(path).glob("turn-*.json")):
        if turn.name.endswith("-run.json"):
            continue
        data = json.loads(turn.read_text(encoding="utf-8"))
        for observation in data["state"]["observations"]:
            tool, identity = observation.get("tool"), observation.get("skill_id")
            if observation.get("status") != "ok":
                continue
            if tool == "search_experiences":
                counts["search_calls"] += 1
            if tool in ("read_skill", "apply_skill"):
                action = "read" if tool == "read_skill" else "applied"
                source = (
                    "learned"
                    if identity in learned
                    else "engineering_builtin"
                    if identity in builtin
                    else "other"
                )
                counts[f"{source}_{action}"] += 1
                ids[action].append(identity)
    return {
        "counts": dict(counts),
        "ids": ids,
        "limit": "Read/activation events establish mechanism use, not causal improvement.",
    }


def public_episode_probe(path):
    """Selection checks all already-executed turns, without reading any grade."""
    probes = []
    for saved in sorted(Path(path).glob("turn-*.json")):
        if saved.name.endswith("-run.json"):
            continue
        row = json.loads(saved.read_text(encoding="utf-8"))
        response = row["response"]
        usage = response["usage"]
        probes.append(
            {
                "status": response["status"],
                "unmet_goals": response["unmet_goals"],
                "observations": row["state"]["observations"],
                "model_calls": usage["model_calls"],
                "estimated_or_reserved_usd": usage["estimated_or_reserved_usd"],
                "input_tokens": sum(
                    (r.get("usage") or {}).get("input_tokens", 0) for r in usage.get("receipts", [])
                ),
                "output_tokens": sum(
                    (r.get("usage") or {}).get("output_tokens", 0) for r in usage.get("receipts", [])
                ),
            }
        )
    return {
        "status": "completed" if probes and all(p["status"] == "completed" for p in probes) else "partial",
        "unmet_goals": [g for p in probes for g in p["unmet_goals"]],
        "observations": [o for p in probes for o in p["observations"]],
        **{
            key: sum(p[key] for p in probes)
            for key in ("model_calls", "estimated_or_reserved_usd", "input_tokens", "output_tokens")
        },
    }


def retry_selection(episode, settings, root, budget, frozen, baseline, allocation):
    """Include H0 as first candidate, spend at most the comparator's extra USD."""
    freeze(
        root / "retry-protocol.json",
        {
            "allocation_usd": allocation,
            "baseline": str(baseline),
            "selection": "max public quality; no hidden labels",
        },
    )
    paths = [baseline]
    attempts = []
    scope = str(root)
    with budget.scope(scope, allocation):
        for index in range(20):
            path = root / f"attempt-{index}"
            previous_calls = len(budget.events)
            try:
                summary = run_episode(episode, settings, path, budget, frozen)
            except RuntimeError as error:
                attempts.append({"error": str(error), "trace": str(path)})
                break
            if (path / "turn-1.json").exists():
                paths.append(path)
            attempts.append({"summary": summary, "trace": str(path)})
            # A denied reservation is not a model call. Do not emit endless empty attempts.
            if len(budget.events) == previous_calls and not (path / "summary.json").exists():
                break
            if summary.get("model_calls", 0) == 0:
                break
            if metrics(budget.scope_events())["usd"] >= allocation:
                break
    selected = max(range(len(paths)), key=lambda i: quality(public_episode_probe(paths[i])))
    report = {
        "extra_allocation_usd": allocation,
        "actual": metrics(budget.scope_events(scope)),
        "attempts": attempts,
        "selected_trace": str(paths[selected]),
        "selected_summary": json.loads((paths[selected] / "summary.json").read_text(encoding="utf-8")),
        "selection_rule": "Public completion, errors, calls, tokens, cost; grades report-only",
        "limits": "Conservative pre-request reservations can leave an unusable residual; at most 20 retries.",
    }
    write(root / "result.json", report)
    return report


def task(episode, settings, root, budget, frozen, incoming, *, all_arms=True):
    root.mkdir(parents=True, exist_ok=True)
    freeze(root / "incoming-bank.json", {"entries": incoming, "episode_id": episode.id})
    with budget.scope(str(root / "h0")):
        baseline = run_episode(episode, settings, root / "h0", budget, frozen)
    bank = copy_bank(incoming)
    if all_arms:
        with budget.scope(str(root / "no-memory")):
            nomem = ppc(episode, settings, root / "no-memory", budget, root / "h0", frozen=frozen)
    with budget.scope(str(root / "memory")):
        memory = ppc(episode, settings, root / "memory", budget, root / "h0", bank, frozen=frozen)
    report = {
        "episode_id": episode.id,
        "entity_group": episode.entity_group,
        "family": episode.family,
        "h0": baseline,
        "ppc_memory": memory,
        "mechanism": mechanism_counts(root / "memory" / "final", incoming),
        "incoming_bank_sha256": content_hash(incoming),
    }
    if all_arms:
        allocated = metrics(budget.scope_events(str(root / "no-memory")))["usd"]
        retry = retry_selection(
            episode, settings, root / "usd-retries", budget, frozen, root / "h0", allocated
        )
        report.update(ppc_no_memory=nomem, usd_retries=retry)
    report["costs"] = {
        name: metrics(budget.scope_events(str(root / name)))
        for name in ("h0", "no-memory", "memory", "usd-retries")
    }
    report["cost_interpretation"] = (
        "Each PPC and retry arm includes the same H0 expense in its total; shared H0 is paid once and disclosed separately."
    )
    write(root / "result.json", report)
    return report, bank.entries


def protocol(settings, frozen, dev, formal, orders):
    source_files = {
        str(p): content_hash(json.loads(p.read_text(encoding="utf-8")))
        for p in [
            frozen / "cases.json",
            frozen / "population-plan.json",
            *frozen.glob("ds_*/manifest.json"),
            *Path("evaluation/frozen").glob("ds_*/manifest.json"),
        ]
        if p.exists()
    }
    return execution_identity(
        settings,
        version="harness-v3-frozen-transfer",
        source_files=source_files,
        development_ids=[e.id for e in dev],
        formal_ids=[e.id for e in formal],
        orders=[[e.id for e in formal], [e.id for e in reversed(formal)]][:orders],
        development_groups=dict(Counter(e.entity_group for e in dev)),
        formal_groups=dict(Counter(e.entity_group for e in formal)),
        formal_families=dict(Counter(e.family for e in formal)),
        formal_bank="read-only development checkpoint copied per task",
        adoption="public observations only; hidden grades report-only",
        retries="same total USD allowance as PPC-no-memory including H0",
        production_seeds="Engineering BUILTINS are present in strong H0; not learned improvements",
        hard_total_usd=40,
        pilot_hard_usd=1,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=["pilot", "development", "formal", "mechanism"], default="pilot")
    parser.add_argument("--output", type=Path, default=Path("data/harness-v3"))
    parser.add_argument("--frozen", type=Path, default=Path("data/core300-frozen"))
    parser.add_argument("--orders", type=int, choices=[1, 2], default=2)
    args = parser.parse_args()
    settings = Settings()
    cases = [
        Episode.model_validate(e)
        for e in json.loads((args.frozen / "cases.json").read_text(encoding="utf-8"))["episodes"]
    ]
    dev, formal = selection(cases)
    freeze(args.output / "protocol.json", protocol(settings, args.frozen, dev, formal, args.orders))
    pilot = args.phase == "pilot"
    budget = StudyBudget(args.output / ("pilot-ledger.json" if pilot else "ledger.json"), 1 if pilot else 40)
    if pilot:
        row, bank = task(dev[0], settings, args.output / "pilot" / dev[0].id, budget, args.frozen, {})
        costs = row["costs"]
        per_task = sum(costs[name]["usd"] for name in costs)
        forecast = {
            "pilot": row,
            "budget": metrics(budget.events),
            "forecast_20dev_40formal_2orders_usd": 20 * (costs["h0"]["usd"] + costs["memory"]["usd"])
            + 80 * per_task,
            "forecast_20dev_40formal_1order_usd": 20 * (costs["h0"]["usd"] + costs["memory"]["usd"])
            + 40 * per_task,
            "forecast_limit": "One single-step development task; multi-turn tasks and editor variance can cost more. Formal study not started.",
            "public_bank": bank,
        }
        write(args.output / "pilot-report.json", forecast)
        print(
            json.dumps({k: v for k, v in forecast.items() if k not in ("pilot", "public_bank")}), flush=True
        )
    elif args.phase == "development":
        bank = {}
        for episode in dev:
            _, bank = task(
                episode,
                settings,
                args.output / "development" / episode.id,
                budget,
                args.frozen,
                bank,
                all_arms=False,
            )
            write(args.output / "development-bank.json", bank)
        freeze(args.output / "frozen-bank.json", {"entries": bank})
    elif args.phase == "formal":
        bank = json.loads((args.output / "frozen-bank.json").read_text(encoding="utf-8"))["identity"][
            "entries"
        ]
        results = []
        for order in range(args.orders):
            for episode in formal if order == 0 else list(reversed(formal)):
                row, _ = task(
                    episode, settings, args.output / f"order-{order}" / episode.id, budget, args.frozen, bank
                )
                results.append(row)
                write(
                    args.output / "formal-report.json",
                    {
                        "results": results,
                        "budget": metrics(budget.events),
                        "unique_tasks": len({r["episode_id"] for r in results}),
                    },
                )
    else:
        bank_path = args.output / "development-bank.json"
        bank = json.loads(bank_path.read_text(encoding="utf-8")) if bank_path.exists() else {}
        results = []
        for episode in dev[8:10]:
            root = args.output / "online-mechanism" / episode.id
            row, next_bank = task(episode, settings, root, budget, args.frozen, bank, all_arms=False)
            ablation = {}
            for policy in ("proactive", "disabled"):
                path = root / policy
                with budget.scope(str(path)):
                    summary = run_episode(
                        episode,
                        settings,
                        path,
                        budget,
                        args.frozen,
                        experiences=list(bank.values()),
                        experience_policy=policy,
                    )
                ablation[policy] = {"summary": summary, "mechanism": mechanism_counts(path, bank)}
            results.append({"row": row, "ablation": ablation})
            bank = next_bank
            write(
                args.output / "online-mechanism-report.json",
                {
                    "results": results,
                    "bank": bank,
                    "limit": "Separate diagnostic online stream, not frozen-transfer test results.",
                },
            )


if __name__ == "__main__":
    main()
