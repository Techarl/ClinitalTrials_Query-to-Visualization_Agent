"""Capsule launcher: inherited credentials, bounded atomic write and secret-free OS diagnostics."""
import json
import os
import runpy
import sys
from pathlib import Path

CAPSULE = Path(__file__).resolve().parents[1]
ROOT = CAPSULE.parent.parent
sys.path.insert(0, str(CAPSULE))
os.chdir(CAPSULE)
from dotenv import load_dotenv
load_dotenv(ROOT / '.env', override=True)

import evaluation.runtime as runtime
assert Path(runtime.__file__).resolve().is_relative_to(CAPSULE)
arguments = sys.argv[1:]
smoke = '--smoke' in arguments
output = ROOT / 'data/harness-v3-infra-smoke02' if smoke else Path(arguments[arguments.index('--output') + 1])
output.mkdir(parents=True, exist_ok=True)
original_write = runtime.write

def diagnosed_write(path, value):
    try:
        return original_write(path, value)
    except OSError as error:
        record = {'error_type':type(error).__name__, 'errno':error.errno,
                  'winerror':getattr(error,'winerror',None), 'filename':error.filename,
                  'filename2':getattr(error,'filename2',None), 'write_target':str(path)}
        try:
            with (output / 'infrastructure-errors.jsonl').open('a',encoding='utf-8') as stream:
                stream.write(json.dumps(record,ensure_ascii=True)+'\n')
        except OSError:
            pass
        raise

runtime.write = diagnosed_write
if not smoke:
    sys.argv = ['experiments.harness_v3', *arguments]
    runpy.run_module('experiments.harness_v3',run_name='__main__')
else:
    import hashlib
    from app.config import Settings
    from evaluation.contracts import Episode
    from evaluation.protocol import freeze, execution_identity
    from experiments.harness_v3 import StudyBudget, metrics, selection, source_hashes
    frozen = ROOT / 'data/core300-frozen'
    settings = Settings()
    cases = [Episode.model_validate(e) for e in json.loads((frozen/'cases.json').read_text(encoding='utf-8'))['episodes']]
    episode = selection(cases)[0][0]
    freeze(output/'protocol.json',execution_identity(settings,episode_id=episode.id,source_files=source_hashes(frozen),
        max_usd=.15, imported_runtime=str(runtime.__file__), only_behavior_change='bounded atomic file replacement; no model/prompt/tool change',
        diagnostics='OS errno/filename only; same original exception re-raised'))
    budget = StudyBudget(output/'ledger.json',.15)
    with budget.scope(str(output)):
        summary = runtime.run_episode(episode,settings,output/'execution',budget,frozen)
    receipt = output/'completed-ledger.json'
    receipt.write_bytes((output/'ledger.json').read_bytes())
    report = {'summary':summary,'budget':metrics(budget.events),'ledger_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),
              'runtime':str(runtime.__file__),'limit':'One infrastructure smoke cannot establish that every filesystem failure is fixed.'}
    runtime.write(output/'report.json',report)
    print(json.dumps(report,ensure_ascii=True),flush=True)
