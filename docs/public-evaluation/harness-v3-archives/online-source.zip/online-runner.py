"""Independent empty-bank two-task online diagnostic. Run only after main02 development closes."""
import hashlib
import json
import os
import sys
from pathlib import Path

CAPSULE = Path(__file__).resolve().parent
ROOT = CAPSULE.parent.parent
os.chdir(CAPSULE)
sys.path.insert(0,str(CAPSULE))
from dotenv import load_dotenv
load_dotenv(ROOT / '.env',override=True)
from app.config import Settings
from evaluation.contracts import Episode
from evaluation.protocol import execution_identity, freeze
from evaluation.runtime import run_episode, write
from experiments.harness_v3 import StudyBudget, selection, task, mechanism_counts, source_hashes, metrics

settings=Settings()
main=ROOT/'data/harness-v3-main02'
output=ROOT/'data/harness-v3-online02'
frozen=ROOT/'data/core300-frozen'

import evaluation.runtime as runtime
original_write = runtime.write
def diagnosed_write(path, value):
    try:
        return original_write(path, value)
    except OSError as error:
        diagnostic = {'error_type':type(error).__name__, 'errno':error.errno,
                      'winerror':getattr(error,'winerror',None), 'filename':error.filename,
                      'filename2':getattr(error,'filename2',None), 'write_target':str(path)}
        try:
            output.mkdir(parents=True, exist_ok=True)
            with (output/'infrastructure-errors.jsonl').open('a',encoding='utf-8') as stream:
                stream.write(json.dumps(diagnostic,ensure_ascii=True)+'\n')
        except OSError:
            pass
        raise
runtime.write = diagnosed_write

cases=[Episode.model_validate(e) for e in json.loads((frozen/'cases.json').read_text(encoding='utf-8'))['episodes']]
dev,_=selection(cases)
used={e.id for e in dev}
pool=[e for e in cases if e.split=='development' and e.family=='compound_phase_start' and e.id not in used]
assert len(pool)==2 and pool[0].entity_group!=pool[1].entity_group
closed=json.loads((main/'development-report.json').read_text(encoding='utf-8'))
assert closed['progress']['evaluated_count']==20, 'Development is incomplete; do not share its live ledger'
assert (main/'frozen-bank.json').exists(), 'Missing closed development checkpoint'
identity=execution_identity(settings,version='harness-v3-independent-empty-bank-online',
    episodes=[e.model_dump(mode='json') for e in pool],initial_bank={},selection='two unused development episodes, same compound family, different diseases',
    policies=['PPC online on public observations','proactive access','disabled access'],
    policy_instruction='At the beginning of a nontrivial task, search for applicable experience, read a relevant version, and activate it only when its applicability matches.',
    ablation_bank='Only incoming prior-task experience; never current-task lesson',source_files=source_hashes(frozen),
    budget_path=str(main/'ledger.json'),max_usd=55,formal_bank='read-only and never updated by this diagnostic',
    limitation='Two development tasks measure mechanism only, not formal efficacy')
identity['code']['online-runner.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
freeze(output/'protocol.json',identity)
# Copy a closed receipt once, before this process becomes the only ledger writer.
receipt=main/'completed-development-ledger.json'
if not receipt.exists(): receipt.write_bytes((main/'ledger.json').read_bytes())
budget=StudyBudget(main/'ledger.json',55)
bank={}
rows=[]
for episode in pool:
    path=output/episode.id
    row,next_bank=task(episode,settings,path,budget,frozen,bank,all_arms=False)
    ablations={}
    for policy in ['proactive','disabled']:
        arm=path/policy
        with budget.scope(str(arm)):
            summary=run_episode(episode,settings,arm,budget,frozen,experiences=list(bank.values()),experience_policy=policy)
        ablations[policy]={'summary':summary,'mechanism':mechanism_counts(arm,bank),'costs':metrics(budget.scope_events(str(arm)))}
    rows.append({'episode_id':episode.id,'row':row,'incoming_bank_count':len(bank),'ablations':ablations})
    bank=next_bank
    write(output/'report.json',{'planned_ids':[e.id for e in pool],'planned_count':2,'evaluated_count':len(rows),
          'unrun_ids':[e.id for e in pool[len(rows):]],'rows':rows,'final_online_bank':bank,
          'cumulative_main_ledger':metrics(budget.events),'limit':'Independent empty-bank online diagnostic; no online entries enter formal transfer bank'})
    print(json.dumps({'online_done':len(rows),'planned':2,'bank_entries':len(bank),'cumulative_main_usd':budget.estimated_usd}),flush=True)
receipt=main/'completed-development-and-online-ledger.json'
receipt.write_bytes((main/'ledger.json').read_bytes())
write(output/'completed-receipt.json',{'ledger':str(receipt),'sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),
                                     'cumulative_development_and_online':metrics(budget.events),'formal_bank':str(main/'frozen-bank.json')})
