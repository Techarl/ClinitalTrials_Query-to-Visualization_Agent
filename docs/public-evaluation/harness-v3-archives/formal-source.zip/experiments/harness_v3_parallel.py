"""Four-worker frozen-bank formal runner; preparation alone never releases paid calls."""

import argparse
import hashlib
import json
import os
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from functools import wraps
from pathlib import Path

from app.config import Settings
from evaluation.contracts import Episode
from evaluation.protocol import execution_identity, freeze
from evaluation.runtime import write
from experiments.harness_v3 import StudyBudget, copy_bank, event_cost, metrics, selection, source_hashes, task


def serialized_snapshot_import(original):
    """Same immutable snapshot imports serialize; unrelated snapshots may progress together."""
    locks = {}
    registry_lock = threading.Lock()

    @wraps(original)
    def guarded(repository, snapshot, studies, deadline=None):
        key = (repository.settings.neo4j_uri, repository.settings.neo4j_database, snapshot.dataset_id)
        with registry_lock:
            gate = locks.setdefault(key, threading.Lock())
        if deadline is None:
            acquired = gate.acquire()
        else:
            acquired = gate.acquire(timeout=max(0, deadline - time.monotonic()))
        if not acquired:
            raise TimeoutError("Graph import admission exceeded the original deadline")
        try:
            return original(repository, snapshot, studies, deadline)
        finally:
            gate.release()

    return guarded


class ThreadScopedBudget(StudyBudget):
    def __init__(self, path, max_usd):
        self.local = threading.local()
        self.global_exhausted = False
        super().__init__(path, max_usd)

    def before(self, context_bytes, output_tokens=4096):
        try:
            return super().before(context_bytes, output_tokens)
        except RuntimeError as error:
            if str(error) == "Research model-call budget exhausted":
                self.global_exhausted = True
            raise

    @property
    def scope_name(self):
        return getattr(self.local, "name", "unassigned")

    @scope_name.setter
    def scope_name(self, value):
        self.local.name = value

    @property
    def scope_limit(self):
        return getattr(self.local, "limit", None)

    @scope_limit.setter
    def scope_limit(self, value):
        self.local.limit = value

    def scope_events(self, name=None):
        with self.lock:
            return super().scope_events(name)


class ScopedBudgetProxy:
    """PPC's len(events) is local to its arm; persistence remains globally complete."""

    def __init__(self, shared):
        self.shared = shared

    @property
    def events(self):
        return self.shared.scope_events()

    def __getattr__(self, name):
        return getattr(self.shared, name)


def infrastructure_failures(path):
    failures = []
    for file in Path(path).rglob("turn-*.json"):
        if file.name.endswith("-run.json"):
            continue
        row = json.loads(file.read_text(encoding="utf-8"))
        for receipt in row.get("response", {}).get("usage", {}).get("receipts", []):
            if receipt.get("error_type") == "PermissionError":
                failures.append(str(file))
    return failures


def run_one(episode, settings, path, shared, frozen, bank):
    proxy = ScopedBudgetProxy(shared)
    # Copy before entering the existing task pipeline, which also copies for PPC.
    row, _ = task(episode, settings, path, proxy, frozen, copy_bank(bank).entries)
    row["infrastructure_failure_receipts"] = infrastructure_failures(path)
    return row


def bounded_run(items, worker, on_result, on_error, should_stop=lambda: False):
    """Exactly four workers, bounded admission, parent-thread-only report writes."""
    iterator = iter(enumerate(items))
    with ThreadPoolExecutor(max_workers=4) as executor:
        pending = {}

        def submit():
            item = next(iterator, None)
            if item is not None:
                index, value = item
                pending[executor.submit(worker, index, value)] = (index, value)

        submit()
        submit()
        submit()
        submit()
        while pending:
            completed, _ = wait(pending, return_when=FIRST_COMPLETED)
            for future in sorted(completed, key=lambda f: pending[f][0]):
                index, value = pending.pop(future)
                try:
                    result = future.result()
                except Exception as error:
                    on_error(index, value, error)
                else:
                    on_result(index, value, result)
            if not should_stop():
                while len(pending) < 4:
                    before = len(pending)
                    submit()
                    if len(pending) == before:
                        break


def prior_receipts(paths):
    total, records, seen = 0.0, {}, set()
    for path in paths:
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest in seen:
            raise ValueError("Duplicate prior ledger receipt")
        seen.add(digest)
        ledger = json.loads(raw)
        value = sum(event_cost(e) for e in ledger["events"])
        total += value
        records[str(path)] = {"sha256": digest, "usd": value, "attempts": len(ledger["events"])}
    return total, records


def main():
    capsule = Path(__file__).resolve().parents[1]
    root = capsule.parent.parent
    os.chdir(capsule)
    from dotenv import load_dotenv

    load_dotenv(root / ".env", override=True)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--frozen", type=Path, required=True)
    parser.add_argument("--bank", type=Path, required=True)
    parser.add_argument("--prior-ledger", type=Path, action="append", required=True)
    parser.add_argument("--total-ceiling-usd", type=float, default=55)
    parser.add_argument("--release-formal", action="store_true")
    args = parser.parse_args()
    if not 0 < args.total_ceiling_usd <= 55:
        parser.error("Total Harness ceiling must be at most the allocated $55")
    args.output, args.frozen, args.bank = args.output.resolve(), args.frozen.resolve(), args.bank.resolve()
    args.prior_ledger = [p.resolve() for p in args.prior_ledger]
    settings = Settings()
    cases = [
        Episode.model_validate(e)
        for e in json.loads((args.frozen / "cases.json").read_text(encoding="utf-8"))["episodes"]
    ]
    _, formal = selection(cases)
    bank = json.loads(args.bank.read_text(encoding="utf-8"))["identity"]["entries"]
    prior_usd, receipts = prior_receipts(args.prior_ledger)
    remaining = args.total_ceiling_usd - prior_usd
    if remaining <= 0:
        raise ValueError("No formal budget remains after all prior receipts")
    freeze(
        args.output / "protocol.json",
        execution_identity(
            settings,
            version="harness-v3-frozen-transfer-four-workers",
            workers=4,
            order=[e.id for e in formal],
            planned_unique_tasks=40,
            planned_runs=40,
            source_files=source_hashes(args.frozen),
            frozen_bank_sha256=hashlib.sha256(args.bank.read_bytes()).hexdigest(),
            bank=bank,
            prior_receipts=receipts,
            prior_usd=prior_usd,
            formal_remaining_usd=remaining,
            total_ceiling_usd=args.total_ceiling_usd,
            admission="Predefined admission order, at most four tasks in flight; completed tasks may finish out of order",
            graph_isolation="Per-task SQLite and output directories; shared immutable snapshot projections; same dataset import lock honors original deadline",
            accounting="Thread-local scope plus per-scope PPC event view; global lock, ledger and reservations",
            infrastructure_stop="Stop admitting tasks after PermissionError appears in two independent task receipts; allow in-flight tasks to close",
            selection="Existing PPC public quality; hidden grades report-only; frozen bank copied per task",
        ),
    )
    if not args.release_formal:
        print(
            json.dumps(
                {
                    "protocol_frozen": True,
                    "formal_released": False,
                    "workers": 4,
                    "planned_unique": 40,
                    "remaining_usd": remaining,
                }
            ),
            flush=True,
        )
        return
    import evaluation.runtime as runtime

    original_write = runtime.write

    def diagnosed_write(path, value):
        try:
            return original_write(path, value)
        except OSError as error:
            diagnostic = {
                "error_type": type(error).__name__,
                "errno": error.errno,
                "filename": error.filename,
                "filename2": getattr(error, "filename2", None),
                "write_target": str(path),
            }
            try:
                with (args.output / "infrastructure-errors.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(diagnostic, ensure_ascii=True) + "\n")
            except OSError:
                pass
            raise

    runtime.write = diagnosed_write
    from app.graphdb import GraphRepository

    GraphRepository.import_snapshot = serialized_snapshot_import(GraphRepository.import_snapshot)
    budget = ThreadScopedBudget(args.output / "ledger.json", remaining)
    results, failures = {}, {}

    def report():
        rows = [results[i] for i in sorted(results)]
        finished = {row["episode_id"] for row in rows}
        failed = {value["episode_id"] for value in failures.values()}
        with budget.lock:
            cost_snapshot, used_snapshot = metrics(budget.events), budget.estimated_usd
        payload = {
            "results": rows,
            "task_exceptions": [failures[i] for i in sorted(failures)],
            "planned_unique": 40,
            "evaluated_count": len(rows),
            "uncaught_failure_count": len(failures),
            "pending_or_unrun_ids": [e.id for e in formal if e.id not in finished | failed],
            "budget": cost_snapshot,
            "prior_usd": prior_usd,
            "combined_harness_usd": prior_usd + used_snapshot,
            "total_ceiling_usd": args.total_ceiling_usd,
            "workers": 4,
        }
        write(args.output / "report.json", payload)

    def success(index, episode, row):
        row["admission_order"] = index
        results[index] = row
        report()
        print(
            json.dumps({"evaluated": len(results), "planned": 40, "formal_usd": budget.estimated_usd}),
            flush=True,
        )

    def failure(index, episode, error):
        failures[index] = {
            "episode_id": episode.id,
            "error_type": type(error).__name__,
            "errno": getattr(error, "errno", None),
            "filename": getattr(error, "filename", None),
        }
        report()

    def stop():
        infrastructure = sum(bool(r.get("infrastructure_failure_receipts")) for r in results.values())
        infrastructure += sum(r["error_type"] == "PermissionError" for r in failures.values())
        return infrastructure >= 2 or budget.global_exhausted or budget.estimated_usd >= budget.max_usd

    report()
    bounded_run(
        formal,
        lambda index, e: run_one(e, settings, args.output / e.id, budget, args.frozen, bank),
        success,
        failure,
        stop,
    )
    report()
    (args.output / "completed-or-stopped-ledger.json").write_bytes((args.output / "ledger.json").read_bytes())


if __name__ == "__main__":
    main()
