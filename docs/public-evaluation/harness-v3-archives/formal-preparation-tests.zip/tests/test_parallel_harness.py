import json
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest
from experiments.harness_v3_parallel import ScopedBudgetProxy, ThreadScopedBudget, bounded_run, prior_receipts

from experiments.harness_v3 import copy_bank, metrics


def test_simultaneous_reservations_share_one_hard_cap(tmp_path):
    budget = ThreadScopedBudget(tmp_path / "ledger.json", 0.05)
    barrier = threading.Barrier(4)

    def attempt(name):
        proxy = ScopedBudgetProxy(budget)
        with proxy.scope(name):
            barrier.wait()
            try:
                return proxy.before(100, 4096)
            except RuntimeError:
                return None

    with ThreadPoolExecutor(max_workers=4) as pool:
        events = list(pool.map(attempt, ["a", "b", "c", "d"]))
    assert sum(e is not None for e in events) == 1
    assert len(budget.events) == 1 and budget.estimated_usd <= 0.05 and budget.global_exhausted
    assert metrics(budget.events)["unknown_usage_calls"] == 1


def test_thread_local_arms_and_ppc_event_views_do_not_mix(tmp_path):
    budget = ThreadScopedBudget(tmp_path / "ledger.json", 1)
    barrier = threading.Barrier(4)

    def worker(name):
        proxy = ScopedBudgetProxy(budget)
        with proxy.scope(name):
            first = proxy.before(100, 1)
            barrier.wait()
            proxy.after(
                first,
                {
                    "provider": "openai",
                    "reported_model": "gpt-6.1-sol",
                    "usage": {
                        "input_tokens": 100,
                        "output_tokens": 1,
                        "total_tokens": 101,
                        "input_tokens_details": {"cached_tokens": 0, "cache_write_tokens": 0},
                    },
                },
            )
            second = proxy.before(200, 2)
            if name == "a":
                proxy.after(second, {"usage": None})
            return len(proxy.events), [e["study_scope"] for e in proxy.events]

    with ThreadPoolExecutor(max_workers=4) as pool:
        result = list(pool.map(worker, ["a", "b", "c", "d"]))
    assert result == [(2, ["a", "a"]), (2, ["b", "b"]), (2, ["c", "c"]), (2, ["d", "d"])]
    assert len(budget.events) == 8 and budget.scope_name == "unassigned"
    assert metrics(budget.events)["unknown_usage_calls"] == 4
    persisted = json.loads((tmp_path / "ledger.json").read_text())
    assert len(persisted["events"]) == 8
    assert len(ScopedBudgetProxy(budget).report()["events"]) == 8


def test_partial_resume_retains_unknown_cost_and_completed_scope_events(tmp_path):
    path = tmp_path / "ledger.json"
    first = ThreadScopedBudget(path, 1)
    with first.scope("finished"):
        event = first.before(100, 1)
        first.after(
            event,
            {
                "provider": "openai",
                "reported_model": "gpt-6.1-sol",
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 1,
                    "total_tokens": 101,
                    "input_tokens_details": {"cached_tokens": 0, "cache_write_tokens": 0},
                },
            },
        )
    with first.scope("interrupted"):
        first.before(500, 100)
    resumed = ThreadScopedBudget(path, 1)
    assert resumed.estimated_usd == first.estimated_usd
    proxy = ScopedBudgetProxy(resumed)
    with proxy.scope("finished"):
        assert len(proxy.events) == 1 and proxy.events[0]["status"] == "completed"
    with proxy.scope("interrupted"):
        assert len(proxy.events) == 1 and proxy.events[0]["status"] == "attempted_usage_unknown"
        proxy.before(100, 1)
        assert len(proxy.events) == 2
    assert len(resumed.events) == 3


def test_task_banks_are_isolated_and_admission_is_four_workers(tmp_path):
    original = {"lesson": {"component": {"skill": "Keep complete evidence"}, "adopted": True}}
    barrier = threading.Barrier(4)
    running = 0
    peak = 0
    mutex = threading.Lock()
    results = {}

    def worker(index, value):
        nonlocal running, peak
        bank = copy_bank(original)
        with mutex:
            running += 1
            peak = max(peak, running)
        bank.entries["lesson"]["component"]["skill"] = str(index)
        barrier.wait()
        with mutex:
            running -= 1
        return bank.entries

    bounded_run(
        [0, 1, 2, 3, 4, 5, 6, 7],
        worker,
        lambda i, v, r: results.update({i: r}),
        lambda *args: pytest.fail(str(args)),
    )
    assert peak == 4 and len(results) == 8
    assert original["lesson"]["component"]["skill"] == "Keep complete evidence"
    assert [results[i]["lesson"]["component"]["skill"] for i in range(8)] == [
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
    ]


def test_local_retry_allowance_denial_does_not_exhaust_global_study(tmp_path):
    budget = ThreadScopedBudget(tmp_path / "ledger.json", 1)
    proxy = ScopedBudgetProxy(budget)
    with proxy.scope("retry", 0.001):
        with pytest.raises(RuntimeError, match="USD-matched"):
            proxy.before(100, 4096)
    assert not budget.global_exhausted and len(budget.events) == 0


def test_prior_closed_receipts_reduce_ceiling_and_duplicates_rejected(tmp_path):
    path = tmp_path / "closed.json"
    path.write_text(
        json.dumps(
            {
                "events": [
                    {"reserved_upper_estimate_usd": 0.2, "status": "attempted_usage_unknown"},
                    {"reserved_upper_estimate_usd": 0.1, "estimated_cost_usd": 0.02, "status": "completed"},
                ]
            }
        )
    )
    total, receipts = prior_receipts([path])
    assert total == pytest.approx(0.22) and receipts[str(path)]["attempts"] == 2
    with pytest.raises(ValueError, match="Duplicate"):
        prior_receipts([path, path])


def test_known_settlement_releases_cost_but_unknown_usage_does_not(tmp_path):
    budget = ThreadScopedBudget(tmp_path / "ledger.json", 0.05)
    with budget.scope("a"):
        event = budget.before(100, 4096)
        with pytest.raises(RuntimeError):
            budget.before(100, 4096)
        budget.after(
            event,
            {
                "provider": "openai",
                "reported_model": "gpt-6.1-sol",
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 1,
                    "total_tokens": 101,
                    "input_tokens_details": {"cached_tokens": 0, "cache_write_tokens": 0},
                },
            },
        )
        unknown = budget.before(100, 4096)
        reserved = budget.estimated_usd
        budget.after(unknown, {"usage": None})
        assert budget.estimated_usd == reserved <= 0.05
        with pytest.raises(RuntimeError):
            budget.before(100, 4096)


def test_parent_report_write_failure_is_not_relabelled_as_task_failure():
    errors = []

    def report(*args):
        raise PermissionError("report file locked")

    with pytest.raises(PermissionError, match="report file locked"):
        bounded_run([1, 2], lambda i, v: v, report, lambda *args: errors.append(args))
    assert errors == []


def test_snapshot_import_gate_serializes_same_dataset_and_preserves_deadline():
    import time
    from types import SimpleNamespace

    from experiments.harness_v3_parallel import serialized_snapshot_import

    repository = SimpleNamespace(settings=SimpleNamespace(neo4j_uri="test", neo4j_database="test"))
    snapshot = SimpleNamespace(dataset_id="ds_isolated")
    entered, release = threading.Event(), threading.Event()
    calls = []

    def original(repo, snap, studies, deadline):
        calls.append((snap.dataset_id, deadline))
        if len(calls) == 1:
            entered.set()
            assert release.wait(2)
        return snap.dataset_id

    guarded = serialized_snapshot_import(original)
    with ThreadPoolExecutor(max_workers=4) as pool:
        first = pool.submit(guarded, repository, snapshot, [], None)
        assert entered.wait(2)
        with pytest.raises(TimeoutError, match="original deadline"):
            guarded(repository, snapshot, [], time.monotonic() + 0.01)
        other = pool.submit(guarded, repository, SimpleNamespace(dataset_id="ds_other"), [], None)
        assert other.result(timeout=1) == "ds_other"
        release.set()
        assert first.result(timeout=1) == "ds_isolated"
    assert [x[0] for x in calls] == ["ds_isolated", "ds_other"]
