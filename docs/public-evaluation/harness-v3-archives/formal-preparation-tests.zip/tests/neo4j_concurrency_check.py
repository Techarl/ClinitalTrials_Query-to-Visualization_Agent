"""No-model-call graph infrastructure check using isolated synthetic snapshots."""
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from uuid import uuid4

CAPSULE = Path(__file__).resolve().parents[1]
ROOT = CAPSULE.parent.parent
os.chdir(CAPSULE)
sys.path.insert(0, str(CAPSULE))
from dotenv import load_dotenv
load_dotenv(ROOT / ".env", override=True)
from app.config import Settings
from app.graphdb import GraphRepository
from app.models import Filters
from app.sources import Snapshot, content_hash, utc_now
from experiments.harness_v3_parallel import serialized_snapshot_import

settings = Settings()
GraphRepository.import_snapshot = serialized_snapshot_import(GraphRepository.import_snapshot)
admin = GraphRepository(settings)
admin.setup()
ids = ["ds_" + uuid4().hex for _ in range(5)]
def fixture(dataset_id, count):
    studies = [{"protocolSection": {
        "identificationModule": {"nctId": "NCT09" + str(i).zfill(6), "briefTitle": "Concurrency fixture"},
        "designModule": {"studyType": "INTERVENTIONAL", "phases": ["PHASE3"]},
        "statusModule": {"overallStatus": "COMPLETED"},
        "conditionsModule": {"conditions": ["Concurrency fixture"]}
    }} for i in range(count)]
    snap = Snapshot(dataset_id=dataset_id, query={"query.cond": "synthetic concurrency fixture"},
                    query_hash="fixture", started_at=utc_now(), finished_at=utc_now(),
                    expected_count=count, retrieved_unique_count=count, complete=True,
                    raw_hash=content_hash(studies))
    return snap, studies

report = {"workers": 4, "paid_model_calls": 0, "source": "synthetic fixtures only"}
try:
    for name, fixtures in [("same_snapshot", [fixture(ids[0], 3)] * 4),
                           ("distinct_snapshots", [fixture(i, n) for n,i in enumerate(ids[1:], 1)])]:
        barrier = threading.Barrier(4)
        def worker(item):
            snap, studies = item
            repository = GraphRepository(settings)
            try:
                barrier.wait(timeout=10)
                repository.import_snapshot(snap, studies, deadline=time.monotonic()+30)
                rows = repository.records(snap.dataset_id, Filters())
                assert len(rows) == len(studies)
                assert {r["record"]["dataset_id"] for r in rows} == {snap.dataset_id}
                return {"dataset_id": snap.dataset_id, "records": len(rows)}
            finally:
                repository.close()
        with ThreadPoolExecutor(max_workers=4) as pool:
            report[name] = list(pool.map(worker, fixtures))
    report["passed"] = True
finally:
    # Only the five generated synthetic fixture datasets; never application data.
    admin.query("MATCH (r:TrialRecord) WHERE r.dataset_id IN $ids DETACH DELETE r", {"ids":ids})
    admin.query("MATCH (d:DatasetSnapshot) WHERE d.dataset_id IN $ids DETACH DELETE d", {"ids":ids})
    admin.close()
report["fixture_snapshots_cleaned"] = ids
out = ROOT / "data/review-followup/harness-v3-neo4j-concurrency-four.json"
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report))
