import sys, threading, json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'data/harness-v3-capsule05'))
from langgraph.graph import StateGraph, START, END
from experiments.harness_v3_parallel import ThreadScopedBudget, ScopedBudgetProxy
budget=ThreadScopedBudget(root/'data/review-followup/synthetic-langgraph-scope-ledger.json',1)
barrier=threading.Barrier(4)
def worker(number):
 proxy=ScopedBudgetProxy(budget)
 parent_id=threading.get_ident()
 def record(state):
  assert threading.get_ident()==parent_id
  proxy.before(100,1)
  return {'count':state['count']+1}
 graph=StateGraph(dict);graph.add_node('choose',record);graph.add_node('execute',record)
 graph.add_edge(START,'choose');graph.add_edge('choose','execute');graph.add_edge('execute',END)
 compiled=graph.compile()
 with proxy.scope('synthetic-'+str(number)):
  barrier.wait(timeout=10)
  result=compiled.invoke({'count':0})
  assert result['count']==2
  assert len(proxy.events)==2
  assert {e['study_scope'] for e in proxy.events}=={'synthetic-'+str(number)}
 return number
with ThreadPoolExecutor(max_workers=4) as pool:
 assert sorted(pool.map(worker,range(4)))==list(range(4))
assert len(budget.events)==8
out={'workers':4,'actual_langgraph_two_node_invokes':4,'events':8,'scope_isolation':'passed','external_model_calls':0,'note':'Synthetic reservations only; exclude this ledger from paid accounting.'}
(root/'data/review-followup/harness-langgraph-scope-check.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out))
